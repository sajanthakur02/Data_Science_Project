# Model training functions

def train_model(X, y):
    pass