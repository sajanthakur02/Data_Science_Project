# Data preprocessing functions

def clean_data(df):
    return df.dropna()