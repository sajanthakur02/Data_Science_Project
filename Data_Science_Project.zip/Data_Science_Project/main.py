# Main script

print('Welcome to the Data Science Project')